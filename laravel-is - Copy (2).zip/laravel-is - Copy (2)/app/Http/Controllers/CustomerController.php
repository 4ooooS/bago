<?php

namespace App\Http\Controllers;
use App\Models\Customer;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CustomerController extends Controller
{
    public function index()
    {
        $data = DB::table("customers")->get();
        return view('customer.index',['customers'=>$data]);
    }
    public function delete($id){
        $delete = DB::table("customers")
        ->where("id","=",$id)
        ->delete();

        return redirect('/')->width('success','Customer deleted successfully');
    } 
    public function addCustomer(){
       return view('customer.add');
    }
    public function saveCustomer(Request $req){
        // dd($req);
        $validated=$req->validate([
            "lastName"=>['required','mid:4'],
            "firstName"=>['required','min:4'],
            "email"=>['required','min4'],
        Rule::unique('user','email'),
            "contactNumber"=>['required','min:11'],
            "address"=>['required','min:4'],
        ]);
    }
    
}


?>